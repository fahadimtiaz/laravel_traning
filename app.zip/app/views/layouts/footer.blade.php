@section("footer")
  <div class="footer">
    <div class="container">
      Powered by <a href="http://laravel.com">Laravel</a>
    </div>
  </div>
@show