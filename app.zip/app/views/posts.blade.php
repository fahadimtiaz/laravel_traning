
@extends('layouts.user')

@section('posts')

{{ Form::open(array('url'=>'', 'class'=>'form-signin')) }}

  <h2 class="form-signin-heading">Create Post</h2>
 
   {{ Form::text('title', null, array('class'=>'input-block-level', 'placeholder'=>'Title')) }}
 
    {{ Form::textarea('body', null,array('class'=>'input-block-level', 'placeholder'=>'Post')) }}
       
   {{ Form::submit('Post', array('class'=>'btn btn-large btn-primary btn-block'))}}
{{ Form::close() }}
