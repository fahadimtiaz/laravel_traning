<?php

class Lesson extends \Eloquent {
	protected $fillable = [];
}