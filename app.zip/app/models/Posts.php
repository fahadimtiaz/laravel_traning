<?php

class Posts extends \Eloquent {
	protected $fillable = [];
}